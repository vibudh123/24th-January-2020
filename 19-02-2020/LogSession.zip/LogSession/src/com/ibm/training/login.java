package com.ibm.training;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.cj.xdevapi.Statement;


@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection dbCon;
	PreparedStatement pstmt;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		HttpSession session = request.getSession();
		String user= request.getParameter("UserName");
		String pass=request.getParameter("password");
		if(session.getAttribute(user)!=null) {
			RequestDispatcher dispatcher= request.getRequestDispatcher("active");
		//dispatcher.forward(request,response); 
//			
			dispatcher.include(request,response);
		}
		
		if(check(user,pass)) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection dbCon = DriverManager.getConnection("jdbc:mysql://localhost:3307/ibmtraining?serverTimezone=IST", "root", "");
		
			String insertQry = "select * from login where userName=? and password=?";
				pstmt = dbCon.prepareStatement(insertQry);
				pstmt.setString(1, user);
				pstmt.setString(2, pass);
				ResultSet rs = pstmt.executeQuery();
				while(rs.next()) {
				if(rs.getString("userName").equals(user) && rs.getString("password").equals(pass)) {
					session.setAttribute("userName", user);
					session.setAttribute("password", pass);
					PrintWriter out = response.getWriter();
					
					out.println("UserName in session : " + request.getSession().getAttribute("userName"));
					
					response.getWriter().print("<br>Into the login successfully...") ;
					response.sendRedirect("active");
//					RequestDispatcher dispatcher= request.getRequestDispatcher("active");
//					//dispatcher.forward(request,response); 
//					dispatcher.include(request,response);
					
				}
				}}
				catch (SQLException e) {
			System.out.println("Can't connect" +e.getMessage());
			
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
				}
				else {
					
					
					response.getWriter().println("Login failed...Incorrect Input!");
					RequestDispatcher dispatcher = request.getRequestDispatcher("index.html");
					RequestDispatcher dispatcher1 = request.getRequestDispatcher("active");
					dispatcher.include(request, response);
					dispatcher1.include(request,response);
				}
				}
							
		
		 
		
		
		
		
//		response.getWriter().append("Connected to DB...");
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}
	public boolean check(String username,String password) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection dbCon = DriverManager.getConnection("jdbc:mysql://localhost:3307/ibmtraining?serverTimezone=IST","root","");
			String idQry = "select userName,password from login";
			java.sql.Statement stmt;
			stmt = dbCon.createStatement();
			ResultSet rs = ((java.sql.Statement) stmt).executeQuery(idQry);
			//ResultSet rs = pstmt.executeQuery(idQry);
				while(rs.next()) {
					if(rs.getString("userName").equals(username) && rs.getString("password").equals(password)) {
						return true;
					}
				}
		} catch (SQLException e) {
			System.out.println("Can't connect" + e.getMessage());
		} catch (ClassNotFoundException e) {
			System.out.println("Driver could not be loaded");
		}
		return false;
	}

}
