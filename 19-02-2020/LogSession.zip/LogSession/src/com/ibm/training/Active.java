package com.ibm.training;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Active
 */
@WebServlet("/active")
public class Active extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(false); 
		response.setContentType("text/html");
		if(session!=null) {
			response.getWriter().println("Welcome to your page " + (String)session.getAttribute("userName"));
			
			response.getWriter().print("<br/><a href=\"after\">Logout</a>");
		}
		else {
			response.sendRedirect("index.html");
		}

	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
