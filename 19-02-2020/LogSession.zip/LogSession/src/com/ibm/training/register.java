package com.ibm.training;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/register")
public class register extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection dbCon;
	PreparedStatement pstmt;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");

		String user= request.getParameter("UserName");
		String pass=request.getParameter("password");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection dbCon = DriverManager.getConnection("jdbc:mysql://localhost:3307/ibmtraining?serverTimezone=IST", "root", "");
		
			String insertQry = "insert into login values(?,?)";
				pstmt = dbCon.prepareStatement(insertQry);
				pstmt.setString(1, user);
				pstmt.setString(2,pass);

				if(pstmt.executeUpdate()>0) {
					
					
					response.getWriter().print("Created successfully...") ;

					RequestDispatcher dispatcher= request.getRequestDispatcher("index.html");
//					dispatcher.forward(request,response); 
					dispatcher.include(request,response);
				}
				else {
					System.out.println("Failed");
				}
				
			
		
		} catch (SQLException e) {
			System.out.println("Can't connect");
			
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
