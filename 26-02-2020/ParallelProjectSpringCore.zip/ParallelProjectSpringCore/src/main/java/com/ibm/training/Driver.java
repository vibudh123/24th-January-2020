package com.ibm.training;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.bean.Customer;
import com.ibm.bean.Transaction;
@Service("driver")
public class Driver {
	
	@Autowired
	ServiceClass serviceClass;
	public boolean flag=true;

	@Autowired
	Customer cust;
	
	@Autowired
	Transaction tran;
	public int userIntInput() {
		
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		while(true) {
			try {
				int intInput = sc.nextInt();
				return intInput;
			}
			catch (Exception e) {
				System.out.println("\nPlease enter an integer input...\n");
				sc.nextLine();
			}
		}
	}
	
	
	
	public String userStrInput() {
		
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		String strInput = sc.next();
		sc.nextLine();
		return strInput;
	}
	public void work() {
		while(true) {
		System.out.println("1. Login to Account Number \n2. Create Account \n3. Exit");
		int a = userIntInput();
		switch(a) {
		case 1:
			System.out.println("Enter account number:");
			int ac = userIntInput();
			cust.setAcc_no(ac);
			System.out.println("What do you want:\n1. View Balance\n2. Fund Transfer \n3. Print Transactions\n4. Deposit Money\n5. Withdraw Money");
			int in = userIntInput();
			switch(in) {
			case 1:
				System.out.println(serviceClass.retrieveBal());
				if(serviceClass.retrieveBal()<100) {
					System.out.println("Balance very low!!!");
				}
				break;
			case 2:
				
				System.out.println("Enter the acc number you want to enter amount:");
				int acc1 = userIntInput();
			
				System.out.println("Enter the amount to be sent:");
				int pas = userIntInput();
				serviceClass.fundTrans(acc1, pas);
				break;
			case 3:
				viewTransactions();
				
				break;
			case 4:
				System.out.println("Enter the amount to be added:");
				int dep = userIntInput();
				serviceClass.AddMoney(dep);
				break;
			case 5:
				System.out.println("Enter the amount to be deducted:");
				int dep1 = userIntInput();
				serviceClass.DeductMoney(dep1);
				break;
			default:
				System.out.println("Invalid Input!!");
			}
			break;
		case 2:
			System.out.println("Enter name:");
			String name = userStrInput();
			cust.setName(name);
			System.out.println("Enter password:");
			String pass = userStrInput();
			cust.setPassword(pass);
			System.out.println("Enter age:");
			int age = userIntInput();
			cust.setAge(age);
			System.out.println("Enter Balance:");
			int bal = userIntInput();
			cust.setBalance(bal);
			tran.setBalance(bal);
			serviceClass.createAccount(cust);
			
			break;
		case 3:
			System.out.println("Exit");
			break;
		default:
			System.out.println("InCorrect Input!!");
		}	
		}
		}
	public  void viewTransactions() {
			List<Transaction> transactions = serviceClass.viewTransactions();
			
			for(Transaction acc:transactions) {
				System.out.println("Account Number :"+acc.getAcc_no()+"..Previous balance:"+acc.getPrevious_balance()+"..Updated Balance"+acc.getBalance()+"..Money Involved:"+acc.getMoney()+"\n");
			}
		}
}
