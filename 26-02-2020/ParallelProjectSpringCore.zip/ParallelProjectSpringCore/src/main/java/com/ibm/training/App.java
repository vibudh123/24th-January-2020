package com.ibm.training;

import org.springframework.context.support.ClassPathXmlApplicationContext;



public class App 
{
	public static void main(String[] args) {
//	@SuppressWarnings("resource")
	ClassPathXmlApplicationContext context =new ClassPathXmlApplicationContext("appContext.xml");
	
	Driver driver= (Driver) context.getBean("driver");
	driver.work();
	}
}
