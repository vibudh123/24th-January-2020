package com.ibm.bean;

import org.springframework.stereotype.Component;

@Component("customer")
public class Customer {
	public int acc_no;
	public String password;
	public String getPassword() {
		return password;
	}
	public void setPassword(String password2) {
		this.password = password2;
	}
	public int getAcc_no() {
		return acc_no;
	}
	public void setAcc_no(int acc_no) {
		this.acc_no = acc_no;
	}

	public String name;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public int age;
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int balance;

	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	
	
}
