package com.ibm.bean;

import org.springframework.stereotype.Component;

@Component("transaction")
public class Transaction {
	public int acc_no;
	
	public int getAcc_no() {
		return acc_no;
	}
	public void setAcc_no(int acc_no) {
		this.acc_no = acc_no;
	}
	
	public int previous_balance;

	public int getPrevious_balance() {
		return previous_balance;
	}
	public void setPrevious_balance(int previous_balance) {
		this.previous_balance = previous_balance;
	}
	
	public int balance;

	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	public int money;

	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	
	
}
