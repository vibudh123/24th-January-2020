package com.ibm.bean;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;




@Repository("dao")
public class daoClass {
	DataSource dataSource;
//	JdbcTemplate jdbcTemplate; 
	NamedParameterJdbcTemplate namedParam;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		namedParam = new NamedParameterJdbcTemplate(dataSource);
	}
	
	public void createAccount(Customer cust) {
		String insertQry = "insert into customer (password,name,age,balance) values(:uPass,:uName,:uAge,:uBal)";

		namedParam.update(insertQry,new MapSqlParameterSource("uName", cust.getName()).addValue("uAge", cust.getAge()).addValue("uPass", cust.getPassword()).addValue("uBal",cust.getBalance()));
		String insertQry1 = "insert into transaction (useraccount,balance) values(:uAcc,:uBal)";
		namedParam.update(insertQry1,new MapSqlParameterSource("uAcc", cust.getAcc_no()).addValue("uBal", cust.getBalance()));
	}
	public boolean login(int accountNumber, String password) {
		String qry = "select * from customer where useraccount=?";
		return namedParam.queryForObject(qry,new MapSqlParameterSource("uAcc", accountNumber), boolean.class);
	}
	public int retrieveBal(int acc) {
		String fetchQry = "select balance from customer where useraccount=(:uAcc)";
		return namedParam.queryForObject(fetchQry,new MapSqlParameterSource("uAcc", acc), Integer.class);
	}
	public void AddMoney(int acc,int prev,int newbal) {
		String updateQry = "update customer set balance = (:uBal) where useraccount = (:uAcc)";
		String updateQry1 = "insert into transaction (useraccount,prevbal,balance,money) values(:uAcc1,:uPrev,:uBal1,:uMoney)";
		int money=newbal-prev;
		namedParam.update(updateQry,new MapSqlParameterSource("uBal",newbal).addValue("uAcc",acc));
		namedParam.update(updateQry1,new MapSqlParameterSource("uBal1",newbal).addValue("uAcc1",acc).addValue("uPrev",prev).addValue("uMoney",money));	
	}
	
	public void DeductMoney(int acc,int prev,int newbal) {
		String updateQry = "update customer set balance = (:uBal) where useraccount = (:uAcc)";
		String updateQry1 = "insert into transaction (useraccount,prevbal,balance,money) values(:uAcc1,:uPrev,:uBal1,:uMoney)";
		int money=prev-newbal;
		namedParam.update(updateQry,new MapSqlParameterSource("uBal",newbal).addValue("uAcc",acc));
		namedParam.update(updateQry1,new MapSqlParameterSource("uBal1",newbal).addValue("uAcc1",acc).addValue("uPrev",prev).addValue("uMoney",money));	
	}
	
	public List<Transaction> viewTransactions(int acc) {
		String fetchQry = "select * from transaction where useraccount = (:uAcc)";
		return namedParam.query(fetchQry,new MapSqlParameterSource("uAcc",acc),new TransactionMapper());
	}

	class CustomerMapper implements RowMapper<Customer>{

	public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
		Customer user=new Customer();
		user.setAcc_no(rs.getInt("useraccount"));
		user.setPassword(rs.getString("password"));
		user.setName(rs.getString("name"));
		user.setAge(rs.getInt("age"));
		user.setBalance(rs.getInt("balance"));
		return user;
	}	
	}
	class TransactionMapper implements RowMapper<Transaction>{

	public Transaction mapRow(ResultSet rs, int rowNum) throws SQLException {
		Transaction user=new Transaction();
		user.setAcc_no(rs.getInt("useraccount"));
		user.setPrevious_balance(rs.getInt("prevbal"));
		user.setBalance(rs.getInt("balance"));
		user.setMoney(rs.getInt("money"));
		return user;
	}	
	}
}