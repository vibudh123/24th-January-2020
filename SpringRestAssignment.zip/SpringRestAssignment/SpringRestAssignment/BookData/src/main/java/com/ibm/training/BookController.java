package com.ibm.training;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@org.springframework.web.bind.annotation.RestController
@RequestMapping("/catalog")
public class BookController {
	
	@Autowired
	RepositoryData repo;
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	void addBook(@RequestBody Book book) {
		repo.save(book);
	}
	
	@RequestMapping(value="/viewall")
	List<Book> view(){
		return (List<Book>) repo.findAll();
	}
}
