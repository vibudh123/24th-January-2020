package com.ibm.training;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@RequestMapping("/book")
public class LinkController {
	
	@Autowired
	RestTemplate template;
	
	@RequestMapping(value = "/add",method=RequestMethod.POST)
	public void addBook(@RequestBody Book book) {
		String url = "http://localhost:8091/catalog/add";
		template.postForObject(url, book, Book.class);
	}
	
	@HystrixCommand(fallbackMethod = "stillWorks")
	@RequestMapping("/view")
	public String view() {
		String url = "http://localhost:8091/catalog/viewall";
		return template.getForObject(url, String.class);
	}
	
	public Iterable<Book> stillWorks()
	{
		return null;

	}
}
